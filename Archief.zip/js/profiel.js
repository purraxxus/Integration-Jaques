var naamLogIn = sessionStorage.getItem('naam');

var tekstVeldLeeg = " ";

$("#naam").html(tekstVeldLeeg).append(naamLogIn);



console.log(naamLogIn);