$(document).ready(function () {



    $.getJSON("JSON/events.json", function (json) //json bestand inladen
        {



        });
});






function goBack() {
    window.history.back()
}
